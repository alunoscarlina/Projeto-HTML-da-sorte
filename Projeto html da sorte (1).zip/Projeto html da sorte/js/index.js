function alertar(){
    alert('Você ganhou R$ 1000,00')
}
